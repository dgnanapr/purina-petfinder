package com.petfinder.rdscdc.sync;

import org.joda.time.DateTime;

public class AnimalsRds {

    private String id;

    private String status;

    private String created_by;

    private DateTime created_at;

    private DateTime arrival_date;

    private String description;

    private String marked_for_deletion;

    private String mixed_breed;

    private String unknown_breed;

    private String animal_type_id;

    private String organization_contact_id;

    private String organization_location_id;

    private String organization_id;

    private String adoption_fee_waived;

    private String display_adoption_fee;

    private String import_updates_enabled;

    private String import_deletes_enabled;

    public void setId(String id){
        this.id = id;
    }
    public String getId(){
        return this.id;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setCreated_by(String created_by){
        this.created_by = created_by;
    }
    public String getCreated_by(){
        return this.created_by;
    }
    public void setCreated_at(DateTime created_at){
        this.created_at = created_at;
    }
    public DateTime getCreated_at(){
        return this.created_at;
    }
    public void setArrival_date(DateTime arrival_date){
        this.arrival_date = arrival_date;
    }
    public DateTime getArrival_date(){
        return this.arrival_date;
    }
    public void setDescription(String description){
        this.description = description;
    }
    public String getDescription(){
        return this.description;
    }
    public void setMarked_for_deletion(String marked_for_deletion){
        this.marked_for_deletion = marked_for_deletion;
    }
    public String getMarked_for_deletion(){
        return this.marked_for_deletion;
    }
    public void setMixed_breed(String mixed_breed){
        this.mixed_breed = mixed_breed;
    }
    public String getMixed_breed(){
        return this.mixed_breed;
    }
    public void setUnknown_breed(String unknown_breed){
        this.unknown_breed = unknown_breed;
    }
    public String getUnknown_breed(){
        return this.unknown_breed;
    }
    public void setAnimal_type_id(String animal_type_id){
        this.animal_type_id = animal_type_id;
    }
    public String getAnimal_type_id(){
        return this.animal_type_id;
    }
    public void setOrganization_contact_id(String organization_contact_id){
        this.organization_contact_id = organization_contact_id;
    }
    public String getOrganization_contact_id(){
        return this.organization_contact_id;
    }
    public void setOrganization_location_id(String organization_location_id){
        this.organization_location_id = organization_location_id;
    }
    public String getOrganization_location_id(){
        return this.organization_location_id;
    }
    public void setOrganization_id(String organization_id){
        this.organization_id = organization_id;
    }
    public String getOrganization_id(){
        return this.organization_id;
    }
    public void setAdoption_fee_waived(String adoption_fee_waived){
        this.adoption_fee_waived = adoption_fee_waived;
    }
    public String getAdoption_fee_waived(){
        return this.adoption_fee_waived;
    }
    public void setDisplay_adoption_fee(String display_adoption_fee){
        this.display_adoption_fee = display_adoption_fee;
    }
    public String getDisplay_adoption_fee(){
        return this.display_adoption_fee;
    }
    public void setImport_updates_enabled(String import_updates_enabled){
        this.import_updates_enabled = import_updates_enabled;
    }
    public String getImport_updates_enabled(){
        return this.import_updates_enabled;
    }
    public void setImport_deletes_enabled(String import_deletes_enabled){
        this.import_deletes_enabled = import_deletes_enabled;
    }
    public String getImport_deletes_enabled(){
        return this.import_deletes_enabled;
    }
}
