package com.petfinder.rdscdc.sync;

public class AnimalsRequest {
	public String getAnimal_id() {
		return animal_id;
	}
	public void setAnimal_id(String animal_id) {
		this.animal_id = animal_id;
	}
	public String getRecord_status() {
		return record_status;
	}
	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}
	public String getOrganization_id() {
		return organization_id;
	}
	public void setOrganization_id(String organization_id) {
		this.organization_id = organization_id;
	}
	public String getLegacy_animal_id() {
		return legacy_animal_id;
	}
	public void setLegacy_animal_id(String legacy_animal_id) {
		this.legacy_animal_id = legacy_animal_id;
	}
	private String animal_id;
	private String record_status;
	private String organization_id;
	private String legacy_animal_id;
}
