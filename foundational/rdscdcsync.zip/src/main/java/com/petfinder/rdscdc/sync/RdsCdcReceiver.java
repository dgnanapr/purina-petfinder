package com.petfinder.rdscdc.sync;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.PutItemSpec;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.google.gson.Gson;

public class RdsCdcReceiver implements RequestHandler<Object, String> {
	private static DynamoDB dynamoDb;
    private String DYNAMODB_TABLE_NAME = "animals";
    private static Regions REGION = Regions.US_EAST_1;
    static {
    	initDynamoDbClient();
    }

    @Override
    public String handleRequest(Object input, Context context) {
        context.getLogger().log("Input: " + input);
        Map inputMap = (HashMap)input;
        context.getLogger().log("inputMap: " + inputMap);
        context.getLogger().log("cdcPayload: " + inputMap.get("cdc_payload"));
        
        String payload=inputMap.get("cdc_payload")+"";
        
        Gson g = new Gson();  
        AnimalsRds animalRds = g.fromJson(payload, AnimalsRds.class);  

        boolean sendToSqs=false;
        if(sendToSqs) {
        
        final AmazonSQS sqs = AmazonSQSClientBuilder.defaultClient();
        
        Map<String, MessageAttributeValue> messageAttributes = new HashMap<String, MessageAttributeValue>();
        
       // messageAttributes.put(key, value)
		SendMessageRequest send_msg_request = new SendMessageRequest()
                .withQueueUrl("https://sqs.us-east-1.amazonaws.com/462477274376/rds_cdc_queue.fifo")
                .withMessageBody(payload)
                .withMessageGroupId("rds_cdc")
                .withMessageDeduplicationId(new Random().nextLong()+"");
        sqs.sendMessage(send_msg_request);

        // TODO: implement your handler
        }else {
            persistData(animalRds,context);        	
        } 
        return "Hello from Lambda!";
    }

    private PutItemOutcome persistData(AnimalsRds animalsRds,Context context) 
      throws ConditionalCheckFailedException {
    	 context.getLogger().log("animalRDS object starting persistData: " + animalsRds);
        return this.dynamoDb.getTable(DYNAMODB_TABLE_NAME)
          .putItem(
            new PutItemSpec().withItem(new Item()
              .withString("legacy_animal_id", animalsRds.getId())
              .withString("record_status", animalsRds.getStatus())
              .withString("organization_id", animalsRds.getOrganization_id())
              .with("create_time", animalsRds.getCreated_at())
              .with("intake_date", animalsRds.getArrival_date())
              .withString("description", animalsRds.getDescription())
              .withBoolean("mixed_breed", animalsRds.getMixed_breed().contentEquals("0")?false:true)
              //unknow breed removed
              //marked for deletion removed
              .withString("animal_type", animalsRds.getAnimal_type_id())
              .withString("legacy_organization_contact_id", animalsRds.getOrganization_contact_id())
              .withString("legacy_organization_location_id", animalsRds.getOrganization_location_id())
              .with("adoption_fee_waived", animalsRds.getAdoption_fee_waived())
              .with("display_adoption_fee", animalsRds.getDisplay_adoption_fee())
              .withString("display_adoption_fee", animalsRds.getDisplay_adoption_fee())
              .withBoolean("import_updates_enabled", animalsRds.getImport_updates_enabled().contentEquals("0")?false:true)
              .withBoolean("import_deletes_enabled", animalsRds.getImport_deletes_enabled().contentEquals("0")?false:true)     
            ));
    }

    private static void initDynamoDbClient() {
        AmazonDynamoDBClient client = new AmazonDynamoDBClient();
        client.setRegion(Region.getRegion(REGION));
        dynamoDb = new DynamoDB(client);
    }
}
